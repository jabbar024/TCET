class MyThread implements Runnable 
{
    @Override
    public void run() 
	{
        	// This method is executed by the thread

        	for (int i = 1; i <= 5; i++) 
		{
            		// Print  current number
            		System.out.println(i);
        	}
    }
}

public class Main 
{
    public static void main(String[] args) 
	{
        	// Create a new thread object, passing a `MyThread` instance as the argument

        	Thread t = new Thread(new MyThread(), "My Thread");

        	// Start the thread
        	t.start();
    	}
}