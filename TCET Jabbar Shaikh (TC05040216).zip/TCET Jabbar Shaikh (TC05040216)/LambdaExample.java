@FunctionalInterface
interface Sayable 
{
    String say(String message);
}

public class LambdaExample 
{
    public static void main(String[] args) 
	{
        	// use lambda expression to implement the Sayable interface

        	Sayable sayable = (message) -> "Hello, " + message + "! Welcome To Test";

        	// calling say method and printing the result

        	System.out.println(sayable.say("Jabbar Shaikh"));
    	}
}
