import java.util.HashMap;
import java.util.Map;

public class WordFrequency 
{
    	public static void main(String[] args) 
	{
        	String inputString = "This is a test string. This string is for testing.";

		// Split the string into words
        	String[] words = inputString.split("\\s+"); 

        	Map<String, Integer> wordFrequency = new HashMap<>();

        	for (String word : words) 
		{
            		wordFrequency.put(word, wordFrequency.getOrDefault(word, 0) + 1);
        	}

        	System.out.println("Word Frequency:");

        	for (Map.Entry<String, Integer> entry : wordFrequency.entrySet()) 
		{
            		System.out.println(entry.getKey() + ": " + entry.getValue());
		}
        
    	}
}