public class Warehouse 
{
    	public static void moveEmptyCrates(int[] crates) 
	{
        	int lastNonEmpty = 0;  // Pointer to track the position of the next non-empty crate
        
        	for (int i = 0; i < crates.length; i++) 
		{
            		if (crates[i] != 0) 
			{
                		// Swap the current element with the element at the lastNonEmpty pointer
                		int temp = crates[lastNonEmpty];
                		crates[lastNonEmpty] = crates[i];
                		crates[i] = temp;
                
                		// update that move to next position
                		lastNonEmpty++;
            		}
        	}
   	}

    	public static void main(String[] args) 
	{
        	int[] crates = {0, 1, 0, 3, 12, 0, 5};
        
        	moveEmptyCrates(crates);
        
        	// Print the result
        	for (int crate : crates) 
		{
            		System.out.print(crate + " ");
        	}
    	}
}
